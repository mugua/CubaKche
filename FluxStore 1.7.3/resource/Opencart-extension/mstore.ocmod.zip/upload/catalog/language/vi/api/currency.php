<?php
// Text
$_['text_success']     = 'Success: Your currency has been changed!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to access the API!';
$_['error_currency']   = 'Warning: Currency code is invalid!';