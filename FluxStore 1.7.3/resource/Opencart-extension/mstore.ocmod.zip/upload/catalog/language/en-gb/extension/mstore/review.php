<?php
// Error
$_['error_permission']  = 'Warning: You do not have permission to modify reviews!';
$_['error_product']     = 'Product required!';
$_['error_author']      = 'Author must be between 3 and 64 characters!';
$_['error_text']        = 'Review Text must be at least 1 character!';
$_['error_rating']      = 'Review rating required!';